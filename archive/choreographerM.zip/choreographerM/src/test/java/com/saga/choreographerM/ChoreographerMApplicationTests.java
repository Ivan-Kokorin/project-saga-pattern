package com.saga.choreographerM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChoreographerMApplicationTests {

	@Test
	void contextLoads() {
	}

}
