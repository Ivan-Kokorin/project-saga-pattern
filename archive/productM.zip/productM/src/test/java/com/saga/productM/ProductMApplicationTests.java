package com.saga.productM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductMApplicationTests {

	@Test
	void contextLoads() {
	}

}
