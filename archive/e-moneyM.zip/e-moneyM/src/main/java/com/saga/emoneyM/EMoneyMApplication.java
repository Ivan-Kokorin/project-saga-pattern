package com.saga.emoneyM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EMoneyMApplication {

	public static void main(String[] args) {
		SpringApplication.run(EMoneyMApplication.class, args);
	}

}
