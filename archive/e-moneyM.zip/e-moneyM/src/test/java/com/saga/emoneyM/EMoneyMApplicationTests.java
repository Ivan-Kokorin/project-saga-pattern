package com.saga.emoneyM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EMoneyMApplicationTests {

	@Test
	void contextLoads() {
	}

}
