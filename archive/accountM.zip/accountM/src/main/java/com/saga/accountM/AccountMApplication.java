package com.saga.accountM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountMApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountMApplication.class, args);
	}

}
